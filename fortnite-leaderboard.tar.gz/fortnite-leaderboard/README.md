# Fortnite Tournament Leaderboard

A sleek, dark-themed tournament tracker for Fortnite competitions. Upload CSV match results and get instant leaderboards with scoring, highlights, and trophy tracking.

![Leaderboard Preview](https://img.shields.io/badge/React-18-blue) ![Vite](https://img.shields.io/badge/Vite-6-purple)

## Features

- **CSV Upload** — Drop in match result files (`PlayerName,Placement,Kills` format). Handles UTF-8 and UTF-16 encoded files.
- **Auto Mode Detection** — Automatically detects Solo, Duo, Trio, or Quad based on shared placements. Manual override available.
- **FNCS-Based Scoring** — Default point system based on Fortnite Champion Series. Fully customizable placement and elimination point values.
- **Multi-Game Aggregation** — Upload multiple CSVs and view combined standings or individual game results.
- **🏆 Highlights Tab** — Podium view showing 1st/2nd/3rd for each game with trophy cards.
- **Trophy Badges** — 🥇🥈🥉 medals displayed inline on player names across all views, with multipliers (×2, ×3) for repeat podiums.
- **Trophy Tally** — Summary of all medals earned per team, sorted by most decorated.
- **🧪 Test Data** — Built-in test data generator to preview the leaderboard instantly.
- **Admin Toggle** — Hide/show upload controls and scoring settings for a clean presentation view.

## CSV Format

Each CSV file should contain rows in this format with **no header row**:

```
PlayerName,Placement,Kills
```

**Duo detection:** When two players share the same placement number, the system groups them as a team.

Example (Duo):
```
ShadowStrike,1,5
NeonViper,1,3
FrostByte,2,4
BlazeMaster,2,1
AquaPhoenix,3,2
ThunderWolf,3,6
```

## Getting Started

```bash
# Clone the repo
git clone https://github.com/YOUR_USERNAME/fortnite-leaderboard.git
cd fortnite-leaderboard

# Install dependencies
npm install

# Start dev server
npm run dev

# Build for production
npm run build
```

## Quick Test

Click the **🧪 Load Test Data** button to populate the leaderboard with randomized test data. Select a mode (Solo/Duo/Trio/Quad) first to generate data in that format.

## Deployment

Build the static site and deploy anywhere:

```bash
npm run build
# Output in dist/ — deploy to Vercel, Netlify, GitHub Pages, etc.
```

For **GitHub Pages**, add to `vite.config.js`:
```js
export default defineConfig({
  base: '/fortnite-leaderboard/',
  plugins: [react()],
})
```

## Tech Stack

- React 18
- Vite 6
- Zero external UI dependencies — pure CSS-in-JS styling

## License

MIT
